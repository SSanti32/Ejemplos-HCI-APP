package ar.edu.itba.example.navigation

import androidx.fragment.app.Fragment

class MainFragment : Fragment(R.layout.fragment_main)
package ar.edu.itba.example.navigation;

import androidx.fragment.app.Fragment;

public class MainFragment extends Fragment {

    public MainFragment() {
        super(R.layout.fragment_main);
    }
}

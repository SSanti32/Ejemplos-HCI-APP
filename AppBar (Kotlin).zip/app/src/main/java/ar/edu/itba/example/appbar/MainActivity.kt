package ar.edu.itba.example.appbar

import android.os.Bundle
import ar.edu.itba.example.appbar.databinding.ActivityMainBinding
import ar.edu.itba.example.appbar.databinding.ToolbarMainBinding

class MainActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding: ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val binding2: ToolbarMainBinding = ToolbarMainBinding.bind(binding.root)
        binding2.toolbar.inflateMenu(R.menu.menu_main)
        setSupportActionBar(binding2.toolbar)
    }
}
package ar.edu.itba.example.appbar

import android.os.Bundle
import android.view.Menu
import ar.edu.itba.example.appbar.databinding.ActivitySettingsBinding
import ar.edu.itba.example.appbar.databinding.ToolbarMainBinding

class SettingsActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: ActivitySettingsBinding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val binding2: ToolbarMainBinding = ToolbarMainBinding.bind(binding.root)
        setSupportActionBar(binding2.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val shareItem = menu.findItem(R.id.action_share)
        shareItem.isVisible = false

        val settingsItem = menu.findItem(R.id.action_settings)
        settingsItem.isVisible = false

        return super.onPrepareOptionsMenu(menu)
    }
}
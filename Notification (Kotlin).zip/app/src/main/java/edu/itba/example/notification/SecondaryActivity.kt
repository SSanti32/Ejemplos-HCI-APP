package edu.itba.example.notification

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import edu.itba.example.notification.databinding.ActivitySecondaryBinding

class SecondaryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivitySecondaryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val intent = intent
        binding.textView.text = intent.getStringExtra(MainActivity.EXTRA_NOTIFICATION_TITLE)
    }
}
package edu.itba.example.lifecycle

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import edu.itba.example.lifecycle.databinding.ActivitySecondaryBinding

class SecondaryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "SecondaryActivity: onCreate()")

        val binding: ActivitySecondaryBinding = ActivitySecondaryBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "SecondaryActivity: onStart()")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "SecondaryActivity: onResume()")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "SecondaryActivity: onPause()")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "SecondaryActivity: onStop()")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "SecondaryActivity: onRestart()")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "SecondaryActivity: onDestroy()")
    }

    companion object {
        const val TAG = "Lifecycle"
    }
}
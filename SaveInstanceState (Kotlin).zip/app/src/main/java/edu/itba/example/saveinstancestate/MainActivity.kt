package edu.itba.example.saveinstancestate

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import edu.itba.example.saveinstancestate.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private var counter = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (savedInstanceState == null) Log.d(TAG, "MainActivity: onCreate() first time") else {
            Log.d(TAG, "MainActivity: onCreate() recreated")

            // Restore counter variable value when activity is recreated
            counter = savedInstanceState.getInt(COUNTER)
        }

        val binding: ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.result.text = resources.getString(R.string.result, counter)
        binding.increment.setOnClickListener {
            ++counter
            binding.result.text = resources.getString(R.string.result, counter)
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "MainActivity: onStart()")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "MainActivity: onResume()")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "MainActivity: onPause()")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "MainActivity: onStop()")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "MainActivity: onRestart()")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "MainActivity: onDestroy()")
    }

    public override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d(TAG, "MainActivity: onSaveInstanceState")

        // Save counter variable current value so it can be restored
        // when activity is recreated
        outState.putInt(COUNTER, counter)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d(TAG, "MainActivity: onRestoreInstanceState")
    }

    companion object {
        const val TAG = "SaveInstanceState"
        const val COUNTER = "counter"
    }
}
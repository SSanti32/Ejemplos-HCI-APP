package edu.itba.example.viewmodel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import edu.itba.example.viewmodel.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val model: MainViewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        showCounter(model.counter)
        binding.increment.setOnClickListener { showCounter(model.incrementCounter()) }
    }

    private fun showCounter(counter: Int) {
        binding.result.text = resources.getString(R.string.result, counter)
    }
}
package edu.itba.example.viewmodel

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    var counter = 0
        private set

    fun incrementCounter(): Int {
        return ++counter
    }
}

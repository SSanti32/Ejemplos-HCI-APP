package ar.edu.itba.example.api.data.network.model

class NetworkUserMetadata
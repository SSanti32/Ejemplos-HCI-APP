1) Descomprimir el ejemplo en un directorio.
1) Abrir una consola o línea de comandos.
2) Posicionarse en el directorio del paso 1 donde se descomprimió el ejemplo.
3) Ejecutar en comando "npm install" sin comillas para instalar las dependencias del proyecto. Las mismas fueron eliminadas para que el archivo sea más liviano.
4) Una vez descargadas las dependencias abrir el proyecto con WebStorm.
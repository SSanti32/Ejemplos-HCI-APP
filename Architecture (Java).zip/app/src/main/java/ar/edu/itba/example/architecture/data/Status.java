package ar.edu.itba.example.architecture.data;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
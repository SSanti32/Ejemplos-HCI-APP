package ar.edu.itba.example.recyclerview

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import ar.edu.itba.example.recyclerview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: CustomAdapter
    private var dataSet = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        for (i in 1..50) addItem(i)

        adapter = CustomAdapter(dataSet)
        binding.recyclerview.layoutManager = LinearLayoutManager(this)
        //binding.recyclerview.setLayoutManager(new GridLayoutManager(this, 3));
        binding.recyclerview.adapter = adapter

        binding.fab.setOnClickListener {
            addItem(dataSet.size + 1)
            //adapter.notifyDataSetChanged();
            adapter.notifyItemInserted(dataSet.size)
        }
    }

    private fun addItem(index: Int) {
        val itemText = resources.getString(R.string.item_text, index)
        dataSet.add(itemText)
    }
}
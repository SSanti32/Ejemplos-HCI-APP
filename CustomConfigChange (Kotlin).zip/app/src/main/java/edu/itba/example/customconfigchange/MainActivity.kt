package edu.itba.example.customconfigchange

import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import edu.itba.example.customconfigchange.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showOrientation(resources.configuration)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.d(TAG, "onConfigurationChanged")

        showOrientation(newConfig)
    }

    private fun showOrientation(config: Configuration) {
        if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            binding.orientation.setText(R.string.landscape)
        } else if (config.orientation == Configuration.ORIENTATION_PORTRAIT) {
            binding.orientation.setText(R.string.portrait)
        }
    }

    companion object {
        const val TAG = "CustomConfigChange"
    }
}